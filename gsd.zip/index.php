<?php
include('include/header.php');
?>
    <!-- Second Container -->
    <div class="container-fluid bg-2 text-center">
        <h3 class="margin">Who we are?</h3>
        <p>"HSF-Marketplace" is an e-commerce for the students of Hochschule Fulda</p>
    </div>
<?php
include('include/footer.php');
?>