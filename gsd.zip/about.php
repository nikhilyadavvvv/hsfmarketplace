<?php
include('include/header.php');
?>

<!-- Second Container -->
<div class="container-fluid bg-2 text-center">
    <h3 class="margin">Our Team</h3>

    <div class="row">
        <div class="col-sm-8 col-md-offset-2">
            <div class="col-sm-4">
                <div class="well bg-5">
                    <img src="images/demo.jpg" class="img-circle" height="55" width="55" alt="Avatar">
                    <p><a href="aboutdam.html">Dan</a></p>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="well bg-5">
                    <img src="images/demo.jpg" class="img-circle" height="55" width="55" alt="Avatar">
                    <p><a href="about_nik.html">Nikhil</a></p>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="well bg-5">
                    <img src="images/demo.jpg" class="img-circle" height="55" width="55" alt="Avatar">
                    <p><a href="Asmita.html">Asmita</a></p>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="well bg-5">
                    <img src="images/demo.jpg" class="img-circle" height="55" width="55" alt="Avatar">
                    <p><a href="kumkum.html">KumKum</a></p>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="well bg-5">
                    <img src="images/demo.jpg" class="img-circle" height="55" width="55" alt="Avatar">
                    <p><a href="usmanaslam.html">Usman</a></p>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="well bg-5">
                    <img src="images/jm.jpg" class="img-circle" height="55" width="55" alt="Avatar">
                    <p><a href="jm.php">Jobayer Mojumder</a></p>
                </div>
            </div>

        </div>
    </div>


</div>

<?php
include('include/footer.php');
?>